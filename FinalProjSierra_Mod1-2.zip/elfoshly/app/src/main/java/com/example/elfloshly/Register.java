package com.example.elfloshly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {

    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://dbfloshlybank-default-rtdb.firebaseio.com/");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText LastName = findViewById(R.id.Lastname);
        final EditText FirstName = findViewById(R.id.firstname);
        final EditText phone = findViewById(R.id.phone);
        final EditText email = findViewById(R.id.email);
        final EditText password = findViewById(R.id.password);
        final EditText Conpassword = findViewById(R.id.Conpassword);

        final Button   RegisterNowbtn  = findViewById(R.id.Registerbtn);
        final TextView LoginNowBtn   = findViewById(R.id.LoginNowBtn);



        RegisterNowbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String LastNamTxt = LastName.getText().toString();
                final String FirstnameTxt = FirstName.getText().toString();
                final String phoneTxt = phone.getText().toString();
                final String emailTxt = email.getText().toString();
                final String passwordTxt = password.getText().toString();
                final String ConpasswordTxt = Conpassword.getText().toString();



                if(LastNamTxt.isEmpty()  || FirstnameTxt.isEmpty() ||  phoneTxt.isEmpty() || emailTxt.isEmpty() || passwordTxt.isEmpty() || ConpasswordTxt.isEmpty()) {

                    Toast.makeText(Register.this, "Please Fill All the field", Toast.LENGTH_SHORT).show();

                }




                 else if(!passwordTxt.equals(ConpasswordTxt)) {
                    Toast.makeText(Register.this, "Password are not matching", Toast.LENGTH_SHORT).show();
                }

                else {
                    databaseReference.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.hasChild(phoneTxt)) {
                                Toast.makeText(Register.this, "phone is already registered", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                databaseReference.child("users").child(phoneTxt).child("Lastname").setValue(LastNamTxt);
                                databaseReference.child("users").child(phoneTxt).child("Firstname").setValue(FirstnameTxt);

                                databaseReference.child("users").child(phoneTxt).child("email").setValue(emailTxt);
                                databaseReference.child("users").child(phoneTxt).child("password").setValue(passwordTxt);

                                Toast.makeText(Register.this, "User Registered Successfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Register.this,MainActivity2.class));
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });



                }

            }
        });
        LoginNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Register.this,LOGIN.class));
            }

        });


    }
}